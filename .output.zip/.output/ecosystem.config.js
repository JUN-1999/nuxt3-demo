module.exports = {
       app: [
           {
               name: 'nuxt',
               port: '3000', //监听端口
               exec_mode: 'cluster',
               instances: 'max',
               script: './server/index.mjs'
           }
       ]
   }
   