import{_ as e}from"./DlAUqK2U.js";import{c as o,o as c}from"./BR7oSNgH.js";const r={};function t(n,s){return c(),o("div",null," posts-1 ")}const f=e(r,[["render",t]]);export{f as default};
