class e extends Error{constructor(r){super(r),this.name="ElementPlusError"}}function o(t,r){throw new e(`[${t}] ${r}`)}export{o as t};
